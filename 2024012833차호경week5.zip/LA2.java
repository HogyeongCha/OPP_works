package week5;

import java.util.Scanner;

public class LA2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of items: ");
        int n = scanner.nextInt();
        scanner.nextLine();
        ShoppingList[] items = createOrder(scanner, n);
        int totalAmount = 0;
        System.out.println("\nAll items entered:");
        for (int j = 0; j < n; j++) {
            items[j].printOrders();
            totalAmount += items[j].getTotalAmount();
        }
        System.out.println("\nMoney needed: " + totalAmount + " Won");
    }

    private static ShoppingList[] createOrder(Scanner scanner, int n) {
        ShoppingList[] items = new ShoppingList[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for item " + (i + 1) + ":");
            System.out.print("Item Name: ");
            String name = scanner.nextLine();
            System.out.print("Price: ");
            int price = scanner.nextInt();
            System.out.print("Count: ");
            int count = scanner.nextInt();
            scanner.nextLine();
            items[i] = new ShoppingList(name, price, count);
        }
        return items;
    }
}
