package week5;

public class LA4 {
    public static void main(String[] args) {
        Book book = new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        book.printBookDetails();
    }
}
