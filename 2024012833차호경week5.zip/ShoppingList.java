package week5;

public class ShoppingList {
    String name;
    int price;
    int count;

    public ShoppingList(String name, int price, int count) {
        this.name = name;
        this.price = price;
        this.count = count;
    }

    public void printOrders() {
        System.out.println("Item Name: " + name + ", Price: " + price + " Won, Count: " + count);
    }

    public int getTotalAmount() {
        return price * count;
    }
}
