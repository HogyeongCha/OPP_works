package week5;

public class Student {
    String name;
    int age;
    int grade;
}