package week8.LA1;

public class SimpleNotepadTest {
    public static void main(String[] args) {
        SimpleNotepad notepad = new SimpleNotepad();
    }
}