package week8.LA2;

public class pizzaOrderGUITest {
    public static void main(String[] args) {
        new PizzaOrderGUI();
    }
}